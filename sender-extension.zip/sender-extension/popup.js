const relayUrlEl = document.getElementById('relayUrl');
const senderNameEl = document.getElementById('senderName');
const statusEl = document.getElementById('status');

async function load() {
	const { relayUrl, senderName, lastPushedAt } = await chrome.storage.local.get([
		'relayUrl', 'senderName', 'lastPushedAt',
	]);
	if (relayUrl) relayUrlEl.value = relayUrl;
	if (senderName) senderNameEl.value = senderName;
	if (lastPushedAt) {
		statusEl.textContent = `Last pushed: ${new Date(lastPushedAt).toLocaleString()}`;
	}
}

document.getElementById('save').addEventListener('click', async () => {
	const url = relayUrlEl.value.trim();
	const name = senderNameEl.value.trim();
	if (!url || !name) {
		statusEl.textContent = 'Fill in both fields.';
		return;
	}
	await chrome.storage.local.set({ relayUrl: url, senderName: name });
	statusEl.textContent = 'Saved.';
});

document.getElementById('syncNow').addEventListener('click', () => {
	statusEl.textContent = 'Pushing...';
	chrome.runtime.sendMessage({ type: 'SYNC_NOW' }, () => {
		statusEl.textContent = `Pushed at ${new Date().toLocaleTimeString()}`;
	});
});

load();
